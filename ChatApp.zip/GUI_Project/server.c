#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <syslog.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/select.h>

#define PORT 7777
#define MAX_CLIENTS 10

typedef struct user // User Information Struct
{
    int cid;
    char name[16];
    char code[32];
} user_t;

user_t client_ids[20] = {0}; // Client Array

int number = 0; // number of people online
int flg = 0;    // private chat sign, if it = 1, then it is a private chat

void mass_send(char *sendbuf) // send to everyone
{
    for (int i = 0; i < 20; i++)
    {
        if (client_ids[i].cid > 0)
        {
            send(client_ids[i].cid, sendbuf, strlen(sendbuf), 0); // Send packaged message history
        }
    }
    // Record Chat history in a txt file
    int fd = open("chat.txt", O_RDWR | O_CREAT | O_APPEND, 0666);
    write(fd, sendbuf, strlen(sendbuf));
    close(fd);
}

void user_add(int cid, char *name, char *code1) // Add user name
{
    for (int i = 0; i < 20; i++)
    {
        if (client_ids[i].cid == cid)
        {
            strcpy(client_ids[i].name, name); // add name
            strcpy(client_ids[i].code, code1); // add name
            break;
        }
    }
}

int username_exists(const char *username)
{
    for (int i = 0; i < 20; i++)
    {
        if (strcmp(client_ids[i].name, username) == 0)
        {
            return 1; // Username exists
        }
    }
    return 0; // Username does not exist
}

int register_user(const char *username, const char *password)
{
    for (int i = 0; i < 20; i++)
    {
        if (client_ids[i].cid == 0)
        {
            strcpy(client_ids[i].name, username);
            strcpy(client_ids[i].code, password);
            return 1; // Registration successful
        }
    }
    return 0; // Registration failed (no empty slot)
}

void handle_registration(int client_sock, char *username, char *password)
{
    // Check if username exists
    if (username_exists(username)) {
        send(client_sock, "Username exists.", strlen("Username exists."), 0);
        return;
    }

    // Register the user
    if (register_user(username, password)) {
        send(client_sock, "-", 1, 0);
    } else {
        send(client_sock, "Registration Failed!", strlen("Registration Failed!"), 0);
    }
}

// sub thread
void *pthread_func(void *arg)
{
    number++;
    printf("Online Population:%d\n", number);

    // get cid
    int client_id = *(int *)arg;

    // Timed Receive Transmit Memory
    char sendbuf[256] = {0};
    char recvbuf[256] = {0};
    char login[16] = {0};
    char name[16] = {0};
    char code1[32] = {0};
    int login1 = 0;

    // Read the name sent by client
    while (1)
    {
        recv(client_id, recvbuf, sizeof(recvbuf), 0);
        if (strncmp(recvbuf, "@", 1) == 0)
        {
            sscanf(recvbuf, " %s %s %s", login, name, code1);
            printf("Accepted new user's data is%s \n", recvbuf);
            // Store the user's account passwords in the struct for easy management.
            user_add(client_id, name, code1);
            send(client_id, "-", sizeof("-"), 0);
            puts("");
            bzero(login, sizeof(login));
            bzero(name, sizeof(name));
            bzero(code1, sizeof(code1));
            bzero(recvbuf, sizeof(recvbuf));
        }
        else if (strncmp(recvbuf, "#", 1) == 0)
        {
            sscanf(recvbuf, " %s %s", login, name);
            if (username_exists(name))
            {
                send(client_id, "Username exists.", strlen("Username exists."), 0);
            }
            else
            {
                send(client_id, "-", sizeof("-"), 0);
            }
            bzero(login, sizeof(login));
            bzero(name, sizeof(name));
            bzero(recvbuf, sizeof(recvbuf));
        }
        else
        {
            if (login1 == 1)
            {
                break;
            }
            sscanf(recvbuf, "%s %s", name, code1);
            printf("The login user -- name: %s , password: %s\n", name, code1);
            int user_found = 0;
            for (int i = 0; i < 20; i++) // find the user
            {
                if (strcmp(client_ids[i].name, name) == 0)
                {
                    user_found = 1;
                    if (strcmp(client_ids[i].code, code1) == 0)
                    {
                        printf("\033[0;32m%s is online\033[0m\n", name);
                        send(client_id, "-", sizeof("-"), 0);
                        login1 = 1;
                        break;
                    }
                    else
                    {
                        printf("\033[0;31mIncorrect password for user %s.\033[0m\n", name);
                        send(client_id, "Incorrect password.", sizeof("Incorrect password."), 0);
                        break;
                    }
                }
            }
            if (!user_found)
            {
                printf("\033[0;31mUser %s does not exist.\033[0m\n", name);
                send(client_id, "User does not exist.", sizeof("User does not exist."), 0);
            }
            bzero(code1, sizeof(code1));
            bzero(recvbuf, sizeof(recvbuf));
        }
    }
    // Send Join Group Chat Message
    char hint[256] = {0};
    strcpy(hint, name);
    strcat(hint, " joined the chat room,");
    strcat(hint, " Current Online Users：");
    for (int n = 0; n < number; n++)
    {
        strcat(hint, client_ids[n].name); // add name
        strcat(hint, " ");
    }
    strcat(hint, "\n");
    mass_send(hint);

    // send message header（username：）
    char namehead[256] = {0};
    strcpy(namehead, name);
    strcat(namehead, ":");

    int len = 0;
    while (1)
    {
        // empty recvbuf
        bzero(recvbuf, sizeof(recvbuf));
        len = recv(client_id, recvbuf, sizeof(recvbuf), 0); // receive data to buf
        if (len <= 0)
        {
            // send to all
            for (int i = 0; i < 20; i++) // Find the exit user and clear the data
            {
                if (strcmp(client_ids[i].name, name) == 0)
                {
                    client_ids[i].cid = 0;
                    bzero(client_ids[i].name, 16);
                    break;
                }
            }
            bzero(hint, sizeof(hint));
            strcpy(hint, name);
            strcat(hint, " exited the chat room, ");
            strcat(hint, " Current Online Users：");
            for (int n = 0; n < 20; n++)
            {
                if (client_ids[n].name != NULL)
                {
                    strcat(hint, client_ids[n].name); // add name
                    strcat(hint, " ");
                }
            }
            strcat(hint, "\n");
            mass_send(hint);
            printf("%s exited the chat room\n", name);
            number--;
            printf(" Current Online Users: %d\n", number);

            sleep(1);
            close(client_id);
            break;
        }
        if (strncmp(recvbuf, "@", 1) == 0)
        {
            flg = 1;
        }
               /***********   private chat    **********/
        if (flg == 1)
        {
            char buf1[16] = "";   // @
            char buf2[16] = "";   // private chat name
            char buf3[256] = "";  // private chat  message

            char *first_space = strstr(recvbuf, " ");
            if (first_space != NULL) {
                *first_space = '\0'; // Temporarily terminate the string at the first space
                strcpy(buf1, recvbuf); // Copy the first part (e.g., @username)
                char *second_space = strstr(first_space + 1, " ");
                if (second_space != NULL) {
                    *second_space = '\0'; // Temporarily terminate the string at the second space
                    strcpy(buf2, first_space + 1); // Copy the second part (the username)
                    strcpy(buf3, second_space + 1); // Copy the rest of the message
                }
            }

            if (strlen(buf1) == 0 || strlen(buf2) == 0 || strlen(buf3) == 0)
            {
                char error[256] = "Note: Private Message Format: @ + name + message\n";
                send(client_id, error, strlen(error), 0);
                flg = 0;
            }
            else
            {
                printf("%s private chat\n", name);
                memset(sendbuf, 0, 256);
                strcpy(sendbuf, name); // add to sender's name
                strcat(sendbuf, " chat to you privately: "); // put in
                strcat(sendbuf, buf3); // Packaging Chat Messages
                strcat(sendbuf, "\n");
                for (int i = 0; i < 20; i++)
                {
                    if (strcmp(client_ids[i].name, buf2) == 0)
                    {
                        send(client_ids[i].cid, sendbuf, strlen(sendbuf), 0);
                        memset(sendbuf, 0, 256);
                        strcpy(sendbuf, "You privately chat to ");
                        strcat(sendbuf, client_ids[i].name);
                        strcat(sendbuf, " says: "); // put in
                        strcat(sendbuf, buf3); // Packaging Chat Messages
                        strcat(sendbuf, "\n");
                        send(client_id, sendbuf, strlen(sendbuf), 0);
                        break;
                    }
                }
                flg = 0;
            }
        }


        /***********   Public chat     **********/
        else
        {
            if (strncasecmp(recvbuf, "quit", 4) == 0) // Exit detected, closed
            {
                printf("[%s] exited the chat room..\n", name);
                number--;
                for (int i = 0; i < 20; i++) // Find the exit user and clear the data
                {
                    if (strcmp(client_ids[i].name, name) == 0)
                    {
                        client_ids[i].cid = 0;
                        bzero(client_ids[i].name, 16);
                        break;
                    }
                }
                bzero(hint, sizeof(hint));
                strcpy(hint, name);
                strcat(hint, " exited the chat room,");
                strcat(hint, "Current Online Users：");
                for (int n = 0; n < 20; n++)
                {
                    if (client_ids[n].name != NULL)
                    {
                        strcat(hint, client_ids[n].name); // add name
                        strcat(hint, " ");
                    }
                }
                strcat(hint, "\n");
                mass_send(hint);
                printf("Current Online:%d\n", number);
                close(client_id);
                break;
            }

            memset(sendbuf, 0, 256);
            strcat(sendbuf, namehead); // add name
            strcat(sendbuf, recvbuf);
            mass_send(sendbuf);
            printf("%s\n", sendbuf);
        }
    }
}

int main(int argc, char **argv)
{
    system("clear");
    if (argc < 3)
    {
        perror("Please Use: ./server + your own IP address + your port number\n");
        return -1;
    }
    int ret = 0;
    /****  1 make socket ****/
    int tcp_server = socket(AF_INET, SOCK_STREAM, 0);

    /***** 2 bound it to own ip and port *****/
    struct sockaddr_in IPV4;
    IPV4.sin_family = AF_INET;
    IPV4.sin_port = htons(atoi(argv[2]));
    IPV4.sin_addr.s_addr = inet_addr(argv[1]);

    ret = bind(tcp_server, (struct sockaddr *)&IPV4, sizeof(IPV4));
    if (ret < 0)
    {
        perror("Failed..\n");
        return -1;
    }

    /******* 3 Listening  ********/
    listen(tcp_server, 10);
    printf("Chat room started successfully, waiting for users to connect..\n");

    /******* 4 Waiting response *********/
    struct sockaddr_in IPV4_client; // client ip and port
    socklen_t IPV4_len = sizeof(IPV4_client);

    pthread_t tid = 0;
    while (1)
    {
        int client_id = accept(tcp_server, (struct sockaddr *)&IPV4_client, &IPV4_len);
        // For each client connection, a new socket is created and a new thread is opened to handle the connection

        /****** 5 deal with chat ******/
        if (client_id > 0)
        {
            for (int i = 0; i < 20; i++)
            {
                if (client_ids[i].cid == 0)
                {
                    client_ids[i].cid = client_id; // add to array, easy to handle
                    printf("[%s:%d]Connecting to the server..\n", inet_ntoa(IPV4_client.sin_addr), ntohs(IPV4_client.sin_port));

                    break;
                }
            }
            /*****  Deal with multi-thread *******/
            pthread_create(&tid, NULL, pthread_func, &client_id);
            pthread_detach(tid);
        }
    }
    close(tcp_server);
    return 0;
}
