#include <gtk/gtk.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <libnotify/notify.h> // Notification
#include <time.h> // Include time.h for timestamp

#define OURPORT 7777
gint sd;
struct sockaddr_in s_in;
gchar username[64];
gchar buf[1024];
gchar get_buf[1048];
gboolean isconnected = FALSE;

static GtkWidget *text_view;
static GtkTextBuffer *buffer;
static GtkWidget *message_entry;
static GtkWidget *name_entry;
static GtkWidget *password_entry;
static GtkWidget *main_window;
static GtkWidget *login_button;
static GtkWidget *register_button;

static GtkTextTag *tag_join, *tag_private, *tag_normal;

void get_message();
gboolean display_chat_message(gpointer data);
void send_message(GtkWidget *widget, gpointer data);
void on_login(GtkWidget *widget, gpointer data);
void on_register(GtkWidget *widget, gpointer data);
void create_chat_window();
void create_main_window();
void show_tips(GtkWidget *widget, gpointer data);

// sign up and login 
void on_login(GtkWidget *widget, gpointer data)
{
    const gchar *name = gtk_entry_get_text(GTK_ENTRY(name_entry));
    const gchar *password = gtk_entry_get_text(GTK_ENTRY(password_entry));
    gchar sendbuff[256] = "";
    gchar recvbuff[256] = "";

    snprintf(username, sizeof(username), "%s", name);
    snprintf(sendbuff, sizeof(sendbuff), "%s %s", name, password);
    send(sd, sendbuff, strlen(sendbuff), 0);
    recv(sd, recvbuff, sizeof(recvbuff), 0);

    if (strcmp(recvbuff, "-") == 0) {
        gtk_widget_destroy(GTK_WIDGET(data));
        gtk_widget_destroy(main_window);
        create_chat_window();
        
        // send 
        gchar blank_message[1] = "";
        send(sd, blank_message, sizeof(blank_message), 0);

    } else if (strcmp(recvbuff, "Incorrect password.") == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_CLOSE,
                                                   "Incorrect password. Please try again.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        gtk_widget_destroy(GTK_WIDGET(data));
    } else if (strcmp(recvbuff, "User does not exist.") == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_CLOSE,
                                                   "User does not exist. Please register.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        gtk_widget_destroy(GTK_WIDGET(data));
    } else {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_CLOSE,
                                                   "Login Failed!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        gtk_widget_destroy(GTK_WIDGET(data));
    }
}

void on_register(GtkWidget *widget, gpointer data)
{
    const gchar *name = gtk_entry_get_text(GTK_ENTRY(name_entry));
    const gchar *password = gtk_entry_get_text(GTK_ENTRY(password_entry));
    gchar sendbuff[256] = "";
    gchar recvbuff[256] = "";

    // First, check if the username already exists
    snprintf(sendbuff, sizeof(sendbuff), "# %s", name);
    send(sd, sendbuff, strlen(sendbuff), 0);
    recv(sd, recvbuff, sizeof(recvbuff), 0);

    if (strcmp(recvbuff, "Username exists.") == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_CLOSE,
                                                   "Username already exists. Please choose another one.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        gtk_widget_destroy(GTK_WIDGET(data)); 
    } else {
        // Proceed with registration
        snprintf(sendbuff, sizeof(sendbuff), "@ %s %s", name, password);
        send(sd, sendbuff, strlen(sendbuff), 0);
        recv(sd, recvbuff, sizeof(recvbuff), 0);

        if (strcmp(recvbuff, "-") == 0) {
            GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                                                       GTK_DIALOG_DESTROY_WITH_PARENT,
                                                       GTK_MESSAGE_INFO,
                                                       GTK_BUTTONS_CLOSE,
                                                       "Registration Successful!");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            gtk_widget_destroy(GTK_WIDGET(data)); // Close the registration dialog
        } 
    }
}

void create_login_register_dialog(GtkWidget *button, gpointer data)
{
    GtkWidget *dialog, *content_area, *label, *hbox;

    dialog = gtk_dialog_new_with_buttons(data ? "Login" : "Register",
                                         GTK_WINDOW(main_window),
                                         GTK_DIALOG_MODAL,
                                         "_OK",
                                         GTK_RESPONSE_OK,
                                         NULL);
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    label = gtk_label_new("Username:");
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
    name_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(hbox), name_entry, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), hbox, TRUE, TRUE, 5);

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    label = gtk_label_new("Password:");
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
    password_entry = gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(password_entry), FALSE);
    gtk_box_pack_start(GTK_BOX(hbox), password_entry, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), hbox, TRUE, TRUE, 5);

    gtk_widget_show_all(dialog);

    gint response = gtk_dialog_run(GTK_DIALOG(dialog));
    if (response == GTK_RESPONSE_OK) {
        if (data)
            on_login(button, dialog);
        else
            on_register(button, dialog);
    } 
}

// main chat gui
void create_main_window()
{
    GtkWidget *window, *vbox, *label;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "KG Chat");
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);
    gtk_window_set_default_size(GTK_WINDOW(window), 250, 400);
    main_window = window;

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    label = gtk_label_new("Welcome to KG Chat");
    gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 5);

    login_button = gtk_button_new_with_label("Login");
    g_signal_connect(login_button, "clicked", G_CALLBACK(create_login_register_dialog), GINT_TO_POINTER(1));
    gtk_box_pack_start(GTK_BOX(vbox), login_button, TRUE, TRUE, 5);

    register_button = gtk_button_new_with_label("Register");
    g_signal_connect(register_button, "clicked", G_CALLBACK(create_login_register_dialog), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), register_button, TRUE, TRUE, 5);

    gtk_widget_show_all(window);
}

// tip
void show_tips(GtkWidget *widget, gpointer data)
{
    GtkWidget *dialog, *label;
    dialog = gtk_dialog_new_with_buttons("Tips",
                                         GTK_WINDOW(main_window),
                                         GTK_DIALOG_MODAL,
                                         "_OK",
                                         GTK_RESPONSE_OK,
                                         NULL);
    GtkWidget *content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    label = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label),
                         "<b><big>Hi, User</big></b>\n"
                         "<b>Welcome to KG Chat Room</b>\n\n"
                         "<b>Tips:</b>\n"
                         "1. Type 'quit' to exit the chat room\n"
                         "2. Private Message Format: @ + name + message\n\n"
                         "<b>Note:</b> This is a public chat room, please watch what you say.\n");
    gtk_box_pack_start(GTK_BOX(content_area), label, TRUE, TRUE, 5);

    gtk_widget_show_all(dialog);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

// clear button 
void clear_chat(GtkWidget *widget, gpointer data)
{
    gtk_text_buffer_set_text(buffer, "", -1); // Clear the text buffer
}

// chat window 
void create_chat_window()
{
    GtkWidget *window, *vbox, *hbox, *scrolled_window, *send_button, *tips_button, *clear_button;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_window_set_title(GTK_WINDOW(window), "KGChat");
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);
    gtk_window_set_default_size(GTK_WINDOW(window), 800, 600);
    main_window = window;

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 5);

    text_view = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(text_view), FALSE);
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    gtk_container_add(GTK_CONTAINER(scrolled_window), text_view);

    // check text
    tag_join = gtk_text_buffer_create_tag(buffer, "join", "foreground", "green", NULL);
    tag_private = gtk_text_buffer_create_tag(buffer, "private", "foreground", "purple", NULL);
    tag_normal = gtk_text_buffer_create_tag(buffer, "normal", "foreground", "black", NULL);

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
    message_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(hbox), message_entry, TRUE, TRUE, 5);

    send_button = gtk_button_new_with_label("Send");
    g_signal_connect(send_button, "clicked", G_CALLBACK(send_message), NULL);
    gtk_box_pack_start(GTK_BOX(hbox), send_button, FALSE, FALSE, 5);

    tips_button = gtk_button_new_with_label("Tips");
    g_signal_connect(tips_button, "clicked", G_CALLBACK(show_tips), NULL);
    gtk_box_pack_start(GTK_BOX(hbox), tips_button, FALSE, FALSE, 5);

    clear_button = gtk_button_new_with_label("Clear Chat"); //To clear chat history
    g_signal_connect(clear_button, "clicked", G_CALLBACK(clear_chat), NULL);
    gtk_box_pack_start(GTK_BOX(hbox), clear_button, FALSE, FALSE, 5);

    gtk_widget_show_all(window);

    g_thread_new(NULL, (GThreadFunc)get_message, NULL);
}

// receive message
void get_message()
{
    gchar recvbuf[256];
    gint num = -1;
    while ((num = recv(sd, recvbuf, sizeof(recvbuf) - 1, 0)) > 0) {
        recvbuf[num] = '\0'; // Ensure null termination
        g_idle_add(display_chat_message, g_strdup(recvbuf));
    }
}

// Notification
void notify_user(const gchar *message)
{
    if (!gtk_window_is_active(GTK_WINDOW(main_window))) {
        NotifyNotification *notification = notify_notification_new("KG Chat", message, NULL);
        notify_notification_set_timeout(notification, 5000); // 5 seconds
        notify_notification_show(notification, NULL);
    }
}

gboolean display_chat_message(gpointer data)
{
    const gchar *msg = (const gchar *)data;
    GtkTextIter iter;
    GtkTextTag *tag = tag_normal;

    // Get the current time
    time_t rawtime;
    struct tm * timeinfo;
    char time_buffer[80];

    time(&rawtime);
    timeinfo = localtime(&rawtime);

    strftime(time_buffer, sizeof(time_buffer), "[%Y-%m-%d %H:%M:%S] ", timeinfo);
    
    // choose diff color base on diff type of message
    if (strstr(msg, " joined the chat room") != NULL || strstr(msg, " exited the chat room") != NULL) {
        tag = tag_join;
    } else if (strstr(msg, "chat to you privately") != NULL || strstr(msg, "You privately chat to") != NULL) {
        tag = tag_private;
    }
    //Insert messages and timestamps
    gtk_text_buffer_get_end_iter(buffer, &iter);
    gtk_text_buffer_insert_with_tags(buffer, &iter, time_buffer, -1, tag, NULL);
    gtk_text_buffer_insert_with_tags(buffer, &iter, msg, -1, tag, NULL);
    gtk_text_buffer_insert(buffer, &iter, "\n", -1);

    notify_user(msg); //Show notification
    g_free(data);
    return FALSE; // To remove the event source after execution
}

void send_message(GtkWidget *widget, gpointer data)
{
    const gchar *message = gtk_entry_get_text(GTK_ENTRY(message_entry));
    if (g_strcmp0(message, "") != 0) {
        send(sd, message, strlen(message), 0);
        gtk_entry_set_text(GTK_ENTRY(message_entry), "");
    }
}

int main(int argc, char *argv[])
{
    if (argc < 3) {
        perror("Please Use: ./client + Server IP Address + Port\n");
        return -1;
    }

    gtk_init(&argc, &argv);
    notify_init("KG Chat"); //notify

    int ret;
    sd = socket(AF_INET, SOCK_STREAM, 0);
    if (sd < 0) {
        perror("socket error\n");
        return -1;
    }

    memset(&s_in, 0, sizeof(s_in));
    s_in.sin_family = AF_INET;
    s_in.sin_port = htons(atoi(argv[2]));
    s_in.sin_addr.s_addr = inet_addr(argv[1]);

    ret = connect(sd, (struct sockaddr *)&s_in, sizeof(s_in));
    if (ret < 0) {
        printf("Connection failed..\n");
        return -1;
    }

    create_main_window();

    gtk_main();
    notify_uninit();
    close(sd);

    return 0;
}
